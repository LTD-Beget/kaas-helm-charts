{{- define "addons.prometheusnodeexporter" }}
name: PrometheusNodeExporter
debug: false
path: helm-chart-sources/prometheus-node-exporter
repoURL: https://github.com/LTD-Beget/kaas-helm-charts
{{- $addonValue := dig "composite" "addons" "prometheusnodeexporter" .Values.composite.addons.common (.Values | toYaml | fromYaml) }}
targetRevision: {{ $addonValue.targetRevision | default "HEAD" }}
pluginName: helm-with-values
default: |
  prometheus-node-exporter:
    service:
      enabled: true
      port: 9100
      labels:
        beget.com/prometheus-job: node-exporter
    containerSecurityContext:
      runAsNonRoot: true
      readOnlyRootFilesystem: true
      allowPrivilegeEscalation: false
    serviceAccount:
      automountServiceAccountToken: true
    resources:
      requests:
        cpu: 100m
        memory: 128Mi
      limits:
        cpu: 512m
        memory: 256Mi
{{- end }}
