{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "svc-hub.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "svc-hub.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "svc-hub.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "svc-hub.labels" -}}
helm.sh/chart: {{ include "svc-hub.chart" . }}
{{ include "svc-hub.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "svc-hub.selectorLabels" -}}
app.kubernetes.io/name: {{ include "svc-hub.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "svc-hub.serviceAccountName" -}}
{{ include "svc-hub.fullname" .}}
{{- end -}}
{{- define  "svc-hub.configmap" -}}
{{- printf "%s-cm" (include "svc-hub.fullname" .) -}}
{{- end -}}
{{- define "svc-hub.podsecuritypolicy" -}}
{{- printf "%s-psp" (include "svc-hub.fullname" .) -}}
{{- end -}}
{{- define "svc-hub.role" -}}
{{- printf "%s-role" (include "svc-hub.fullname" .) -}}
{{- end -}}
{{- define "svc-hub.rolebinding" -}}
{{- printf "%s-rolebinding" (include "svc-hub.fullname" .) -}}
{{- end -}}