{{- define "in-cloud-capi-template.files.postKubeadmCommands.commands.sh" -}}
- path: /etc/default/postKubeadmCommand/commands.sh
  owner: root:root
  permissions: '0755'
  content: |
    #!/bin/bash

    KUBECONFIG=/etc/kubernetes/admin.conf
    export KUBECONFIG

    kubectl get namespace {{ $.Values.companyPrefix }}-system >/dev/null 2>&1 || kubectl create namespace {{ $.Values.companyPrefix }}-system

    DONE_FILE=/var/lib/{{ $.Values.companyPrefix }}/addons-bootstrap.done
    mkdir -p /var/lib/{{ $.Values.companyPrefix }}

    #Адрес kube-Api
    KUBEAPI_HOST=$(kubectl config view -o jsonpath='{.clusters[0].cluster.server}' --minify=true | awk -F/ '{print $NF}' | awk -F: '{print $1}')

    # Сколько control-plane нод уже в кластере
    CP_COUNT=$(kubectl --kubeconfig=/etc/kubernetes/admin.conf get nodes \
      -l node-role.kubernetes.io/control-plane \
      --no-headers 2>/dev/null | wc -l)

    if [ "$CP_COUNT" -ne 1 ]; then
      echo "Not first control-plane node, skipping helm install"
      exit 0
    fi

    echo "First control-plane node detected → running helm install"

    # ---- (1) вытаскиваем endpoint host/port из admin.conf ----
    APISERVER_URL="$(kubectl --kubeconfig="$KUBECONFIG" config view --minify -o jsonpath='{.clusters[0].cluster.server}')"
    if [[ -z "$APISERVER_URL" ]]; then
      logger -t "$LOG_TAG" "[ERROR] can't read apiserver url from $KUBECONFIG"
      exit 1
    fi

    CLUSTER_ENDPOINT_HOST="$(echo "$APISERVER_URL" | sed -E 's#https?://([^:/]+).*#\1#')"
    CLUSTER_ENDPOINT_PORT="$(echo "$APISERVER_URL" | sed -E 's#.*:([0-9]+)$#\1#')"
    if [[ "$CLUSTER_ENDPOINT_PORT" == "$APISERVER_URL" ]]; then
      CLUSTER_ENDPOINT_PORT=6443
    fi

    export CLUSTER_ENDPOINT_HOST
    export CLUSTER_ENDPOINT_PORT
    export CLUSTER_DNS_HOST="{{`{{ .clusterDnsSvc }}`}}"
    export CLUSTER_IPAM_MODE="{{`{{ .clusterIpamMode }}`}}"

    logger -t "$LOG_TAG" "[INFO] apiserver endpoint: ${CLUSTER_ENDPOINT_HOST}:${CLUSTER_ENDPOINT_PORT}"

    # ---- (2) рабочая директория ----
    TEMPDIRCLUSTER="$(mktemp -d)"
    logger -t "$LOG_TAG" "[INFO] workdir: $TEMPDIRCLUSTER"
    cd "$TEMPDIRCLUSTER"

    export MAX_ATTEMPTS=5

    retry() {
      local operation="$1"
      shift

      local attempt=1
      local retry_delay

      while (( attempt <= MAX_ATTEMPTS )); do
        logger -t "$LOG_TAG" "[INFO] ${operation}, attempt ${attempt}/${MAX_ATTEMPTS}..."

        if "$@"; then
          logger -t "$LOG_TAG" "[INFO] ${operation} completed successfully on attempt ${attempt}"
          return 0
        fi

        if (( attempt == MAX_ATTEMPTS )); then
          logger -t "$LOG_TAG" "[ERROR] ${operation} failed after ${MAX_ATTEMPTS} attempts"
          return 1
        fi

        retry_delay=$((10 * attempt))
        logger -t "$LOG_TAG" "[WARN] ${operation} failed; retrying in ${retry_delay}s"
        sleep "$retry_delay"

        ((attempt++))
      done
    }

    # ---- (3) helm add + update ----
    logger -t "$LOG_TAG" "[INFO] adding {{ $.Values.companyPrefix }} charts repo..."

    retry "adding {{ $.Values.companyPrefix }} charts repo" \
      helm repo add {{ $.Values.companyPrefix }} https://blog.{{ $.Values.companyDomain }}/kaas-helm-charts/ --force-update || exit 1

    logger -t "$LOG_TAG" "[INFO] updating {{ $.Values.companyPrefix }} charts repo..."
    retry "updating {{ $.Values.companyPrefix }} charts repo" \
      helm repo update {{ $.Values.companyPrefix }} || exit 1

    # ---- (4) ставим аддоны через helm ----
    logger -t "$LOG_TAG" "[INFO] install/upgrade cilium..."

    echo "System cluster detected → waiting for InternalIP"
    kubectl wait --timeout=-1s node -l node-role.kubernetes.io/control-plane \
      --for=jsonpath='{.status.addresses[?(@.type=="InternalIP")].address}'

    if [[ "${CLUSTER_IPAM_MODE}" == "multi-pool" ]]; then
      IPAM_VALUES=$(cat <<'EOF'
          ipam:
            mode: multi-pool
            operator:
              autoCreateCiliumPodIPPools:
                default:
                  ipv4:
                    cidrs:
                      - "{{ .Values.podCidr }}"
                    maskSize: {{ .Values.podCidrMaskSize }}
          bpf:
            masquerade: true
    EOF
    )
    else
      IPAM_VALUES=$(cat <<'EOF'
          ipam:
            operator:
              clusterPoolIPv4MaskSize: {{ .Values.podCidrMaskSize }}
              clusterPoolIPv4PodCIDRList:
                - "{{ .Values.podCidr }}"
    EOF
    )
    fi

    CILIUM_VALUES_FILE="${TEMPDIRCLUSTER}/cilium-values.yaml"
    cat <<EOF > "$CILIUM_VALUES_FILE"
    cilium:
      ciliumEndpointSlice:
        enabled: true
      dnsPolicy: ClusterFirstWithHostNet
      envoy:
        enabled: false
      hubble:
        enabled: false
      k8sServiceHost: ${CLUSTER_ENDPOINT_HOST}
      k8sServicePort: ${CLUSTER_ENDPOINT_PORT}
      kubeProxyReplacement: true
      operator:
        replicas: 1
        tolerations:
          - operator: Exists
            effect: NoSchedule

    ${IPAM_VALUES}

      resources:
        requests:
          cpu: 100m
          memory: 100Mi
      tls:
        readSecretsOnlyFromSecretsNamespace: false
        secretSync:
          enabled: false
        secretsNamespace:
          create: false
          name: null
      tolerations:
        - operator: Exists
          effect: NoSchedule
    EOF

    # TODO: delete chart version hardcode
    retry "installing cilium" \
      helm install cilium {{ $.Values.companyPrefix }}/cilium \
        -n {{ $.Values.companyPrefix }}-cilium \
        --create-namespace \
        --version 1.19.4-1 \
        -f "$CILIUM_VALUES_FILE" || exit 1

    logger -t "$LOG_TAG" "[INFO] install/upgrade coredns..."
    # TODO: delete chart version hardcode
    COREDNS_VALUES_FILE="${TEMPDIRCLUSTER}/coredns-values.yaml"
    cat <<EOF > "$COREDNS_VALUES_FILE"
    coredns:
      livenessProbe:
        initialDelaySeconds: 10
        periodSeconds: 5
        timeoutSeconds: 3
        failureThreshold: 10
      readinessProbe:
        initialDelaySeconds: 10
        periodSeconds: 5
        timeoutSeconds: 3
        failureThreshold: 10
      priorityClassName: system-cluster-critical
      resources:
        limits:
          cpu: 200m
          memory: 256Mi
      rollingUpdate:
        maxUnavailable: 35%
        maxSurge: 1
      securityContext:
        readOnlyRootFilesystem: true
        runAsNonRoot: false
        runAsUser: 0
      servers:
      - plugins:
        - configBlock: |-
            pods verified
            fallthrough in-addr.arpa ip6.arpa
            ttl 30
          name: kubernetes
          parameters: cluster.local in-addr.arpa ip6.arpa
        - configBlock: to *
          name: transfer
        - name: loop
        - name: reload
        - name: errors
        - name: ready
        - name: loadbalance
          parameter: round_robin
        - name: forward
          parameters: . /etc/resolv.conf
        - name: cache
          parameters: 30
        - name: prometheus
          parameters: 0.0.0.0:9153
        - configBlock: class all
          name: log
        - configBlock: lameduck 5s
          name: health
        port: 53
        zones:
        - zone: cluster.local.
      - plugins:
        - name: loop
        - name: reload
        - name: errors
        - name: ready
        - name: loadbalance
          parameter: round_robin
        - configBlock: force_tcp
          name: forward
          parameters: . /etc/resolv.conf
        - name: cache
          parameters: 30
        - name: prometheus
          parameters: 0.0.0.0:9153
        - configBlock: class all
          name: log
        - configBlock: lameduck 5s
          name: health
        port: 53
        zones:
        - zone: .
      service:
        clusterIP: ${CLUSTER_DNS_HOST}
      serviceAccount:
        create: true
        name: coredns
      tolerations:
      - operator: Exists
        effect: NoSchedule
    EOF

    # TODO: delete chart version hardcode
    retry "installing coredns" \
      helm install coredns {{ $.Values.companyPrefix }}/coredns \
        -n {{ $.Values.companyPrefix }}-coredns \
        --create-namespace \
        --version 1.28.0-4 \
        -f "$COREDNS_VALUES_FILE" || exit 1

    kubectl wait --timeout=-1s --for=condition=Ready pod -l app.kubernetes.io/instance=coredns -n {{ $.Values.companyPrefix }}-coredns

    logger -t "$LOG_TAG" "[INFO] install/upgrade argocd..."
    # TODO: delete chart version hardcode
    ARGOCD_VALUES_FILE="${TEMPDIRCLUSTER}/argocd-values.yaml"
    cat <<'EOF' > "$ARGOCD_VALUES_FILE"
    argo-cd:
      fullnameOverride: "argocd"
      applicationSet:
        replicas: 0
      configs:
        cm:
          application.resourceTrackingMethod: annotation
          reposerver.default.cache.expiration: 8h0m0s
          reposerver.repo.cache.expiration: 8h0m0s
          resource.compareoptions: |
            ignoreAggregatedRoles: true
          resource.customizations.ignoreDifferences.admissionregistration.k8s.io_MutatingWebhookConfiguration: |
            jqPathExpressions:
            - '.webhooks[]?.clientConfig.caBundle'
          resource.customizations.ignoreDifferences.admissionregistration.k8s.io_ValidatingWebhookConfiguration: |
            jqPathExpressions:
            - '.webhooks[]?.clientConfig.caBundle'
          resource.customizations.ignoreDifferences.all: |
            jqPathExpressions:
            - '.spec.template.spec.containers[].volumeMounts[] | select(.name == "ssl-certs")'
            - '.spec.template.spec.volumes[] | select(.name == "ssl-certs")'
            - '.spec.template.spec.securityContext'
            - '.spec.template.spec.containers[].securityContext'
            - '.spec.template.spec.initContainers[].securityContext'
            - '.spec.replicas'
          resource.customizations.ignoreDifferences.kyverno.io_ClusterPolicy: |
            jqPathExpressions:
            - '.spec.rules[] | select(.name|test("autogen-."))'
          resource.customizations.ignoreDifferences.kyverno.io_Policy: |
            jqPathExpressions:
            - '.spec.rules[] | select(.name|test("autogen-."))'
          kustomize.buildOptions: --enable-helm
          timeout.reconciliation: 10s
          timeout.reconciliation.jitter: 10s
          url: "https://localhost/argocd"
        cmp:
          create: true
          plugins:
            helm-with-values:
              allowConcurrency: true
              discover:
                find:
                  command:
                  - bash
                  - -c
                  - |
                    if [ -n "${ARGOCD_ENV_HELM_VALUES+set}" ] ; then
                      find . -name 'Chart.yaml' &&
                      find . -name 'values.yaml'
                    fi
              generate:
                command:
                - bash
                - -c
                - |
                  #!/bin/bash
                  set -e

                  if [ -z "${ARGOCD_ENV_RELEASE_NAME}" ]; then
                      ARGOCD_ENV_RELEASE_NAME="${ARGOCD_APP_NAME#*_}"
                  fi

                  echo "${ARGOCD_ENV_HELM_VALUES}" | base64 -d > ./additionalValues.yaml

                  KUSTOMIZE_ENABLED=$(yq e '.argocdPlugins.kustomize // false' ./additionalValues.yaml)
                  VAULT_ENABLED=$(yq e '.argocdPlugins.vault // false' ./additionalValues.yaml)

                  if [ "$KUSTOMIZE_ENABLED" = "true" ]; then
                      helm template "${ARGOCD_ENV_RELEASE_NAME}" --include-crds -n "${ARGOCD_APP_NAMESPACE}" -f ./additionalValues.yaml . > ./patches/base.yaml

                      OUTPUT=$(kustomize build ./patches)
                  else
                      OUTPUT=$(helm template "${ARGOCD_ENV_RELEASE_NAME}" --include-crds -n "${ARGOCD_APP_NAMESPACE}" -f ./additionalValues.yaml .)
                  fi

                  if [ "$VAULT_ENABLED" = "true" ]; then
                      echo "$OUTPUT" | argocd-vault-plugin generate -s {{ $.Values.companyPrefix }}-argocd:avp-config -
                  else
                      echo "$OUTPUT"
                  fi
              lockRepo: false
        params:
          application.namespaces: '*'
          applicationsetcontroller.allowed.scm.providers: https://gitlab.{{ $.Values.companyPrefix }}.ru
          applicationsetcontroller.namespaces: '*'
          # repo.server: 127.0.0.1:8081
          # redis.server: 127.0.0.1:6379
          controller.sharding.algorithm: round-robin
          server.basehref: /argocd
          server.rootpath: /argocd
          server.staticassets: /shared/app
        secret:
          argocdServerAdminPassword: "$2a$10$3MqvSHzzSj38YYNFDrkolONgKe9ejuphtk1Qe5gWNdm9ILVQYUOma"
          argocdServerAdminPasswordMtime: "2025-10-30T16:30:50Z"
      controller:
        dynamicClusterDistribution: true
        image:
          imagePullPolicy: IfNotPresent
        replicas: 1
        resources:
          limits:
            cpu: "4"
            ephemeral-storage: 10Gi
          requests:
            cpu: 200m
            ephemeral-storage: 500Mi
            memory: 200Mi
        volumes:
          - hostPath:
              path: /etc/kubernetes/admin.conf
              type: FileOrCreate
            name: admin-conf
        volumeMounts:
          - mountPath: /etc/kubernetes/admin.conf
            name: admin-conf
      crds:
          install: true
      dex:
        enabled: false
      extraObjects:
      - apiVersion: v1
        kind: Secret
        metadata:
          name: avp-config
          namespace: {{ $.Values.companyPrefix }}-argocd
        stringData:
          AVP_AUTH_TYPE: k8s
          AVP_K8S_ROLE: credentials-ro
          AVP_TYPE: vault
          VAULT_ADDR: http://vault.{{ $.Values.companyPrefix }}-vault.svc.cluster.local:8200
        type: Opaque
      global:
        deploymentStrategy:
          type: RollingUpdate
        tolerations:
        - operator: Exists
          effect: NoSchedule
      notifications:
        enabled: false
      redis:
        resources:
          limits:
            cpu: 1
            memory: 1Gi
          requests:
            cpu: 100m
            ephemeral-storage: 100Mi
            memory: 128Mi
      redisSecretInit:
        enabled: true
      repoServer:
        envFrom:
        - secretRef:
            name: avp-config
        extraContainers:
        - command:
          - /var/run/argocd/argocd-cmp-server
          image: dmkolbin/argocd-with-utils:v2.14.10
          name: helm-with-values
          securityContext:
            runAsNonRoot: true
            runAsUser: 999
          volumeMounts:
          - mountPath: /var/run/argocd
            name: var-files
          - mountPath: /home/argocd/cmp-server/plugins
            name: plugins
          - mountPath: /home/argocd/cmp-server/config/plugin.yaml
            name: cmp-plugin
            subPath: helm-with-values.yaml
        resources:
          limits:
            cpu: 8
            ephemeral-storage: 10Gi
            memory: 8Gi
          requests:
            cpu: 100m
            ephemeral-storage: 10Gi
            memory: 128Mi
        volumes:
        - configMap:
            name: argocd-cmp-cm
          name: cmp-plugin
      server:
        volumes:
          - hostPath:
              path: /etc/kubernetes/admin.conf
              type: FileOrCreate
            name: admin-conf
        volumeMounts:
          - mountPath: /etc/kubernetes/admin.conf
            name: admin-conf
    EOF

    # TODO: delete chart version hardcode
    retry "installing argocd" \
      helm install argocd {{ $.Values.companyPrefix }}/argo-cd \
        -n {{ $.Values.companyPrefix }}-argocd \
        --create-namespace \
        --version 9.4.15-5 \
        -f "$ARGOCD_VALUES_FILE" || exit 1

    logger -t "$LOG_TAG" "[INFO] install/upgrade addon-operator..."
    # TODO: delete chart version hardcode
    ADDONS_OPERATOR_VALUES_FILE="${TEMPDIRCLUSTER}/addons-operator-values.yaml"
    cat <<EOF > "$ADDONS_OPERATOR_VALUES_FILE"
    certManager:
      enable: false
    manager:
      env:
      - name: ENABLE_WEBHOOKS
        value: false
      image:
        repository: prorobotech/addons-operator
        pullPolicy: IfNotPresent
      tolerations:
      - operator: Exists
        effect: NoSchedule
    metrics:
      enable: false
      port: 8443
    webhook:
      enable: false
    EOF

    # TODO: delete chart version hardcode
    retry "installing addons-operator" \
      helm install addons-operator {{ $.Values.companyPrefix }}/addon-operator \
        -n {{ $.Values.companyPrefix }}-addons-operator \
        --create-namespace \
        --version 0.1.6 \
        -f "$ADDONS_OPERATOR_VALUES_FILE" || exit 1

    kubectl wait --timeout=-1s --for=condition=Ready pod -l app.kubernetes.io/component=application-controller -n {{ $.Values.companyPrefix }}-argocd
    kubectl wait --timeout=-1s --for=condition=Ready pod -l app.kubernetes.io/component=redis -n {{ $.Values.companyPrefix }}-argocd
    kubectl wait --timeout=-1s --for=condition=Ready pod -l app.kubernetes.io/component=repo-server -n {{ $.Values.companyPrefix }}-argocd
    kubectl wait --timeout=-1s --for=condition=Ready pod -l app.kubernetes.io/component=server -n {{ $.Values.companyPrefix }}-argocd

    # ---- (5) apply addonset static-manifest ----

    kubectl wait --timeout=-1s --for=jsonpath='{.data.addonRevision}' cm -n {{ $.Values.companyPrefix }}-system parameters-infra
    kubectl wait --timeout=-1s --for=jsonpath='{.data.companyExternalChartRegistry}' cm -n {{ $.Values.companyPrefix }}-system parameters-infra
    kubectl wait --timeout=-1s --for=jsonpath='{.data.companyPrefix}' cm -n {{ $.Values.companyPrefix }}-system parameters-infra

    params=$(kubectl get cm -n {{ $.Values.companyPrefix }}-system parameters-infra -o json | jq '.data')
    addonRevision=$(jq -r '.addonRevision' <<< $params)
    companyExternalChartRegistry=$(jq -r '.companyExternalChartRegistry' <<< $params)
    companyPrefix=$(jq -r '.companyPrefix' <<< $params)

    retry "installing bootstrap" \
      helm install bootstrap \
        {{ $.Values.companyPrefix }}/bootstrap \
        --version "${addonRevision}" \
        --set "companyPrefix=${companyPrefix}" \
        --set "companyExternalChartRegistry=${companyExternalChartRegistry}" \
        -n {{ $.Values.companyPrefix }}-system || exit 1

    logger -t "$LOG_TAG" "[INFO] applying Addon CR..."

    date -Is > "$DONE_FILE"
    logger -t "$LOG_TAG" "[INFO] addons bootstrap done: $(cat "$DONE_FILE")"

{{- end }}
