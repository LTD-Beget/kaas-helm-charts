{{- define "cilium.phase" }}
---
apiVersion: addons.in-cloud.io/v1alpha1
kind: AddonPhase
metadata:
  name: cilium{{ if eq .Values.environment "client" }}-client{{ end }}
spec:
  rules:
    - name: vm-operator
      criteria:
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: cert-manager{{ if eq .Values.environment "client" }}-client{{ end }}
          jsonPath: $.status.phaseValuesSelector[?(@.name=='initialized-2')]
          operator: Exists
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: cert-manager{{ if eq .Values.environment "client" }}-client{{ end }}
          jsonPath: $.spec.variables.dependency
          operator: Equal
          value: "True"
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: vm-operator{{ if eq .Values.environment "client" }}-client{{ end }}
          jsonPath: $.status.deployed
          operator: Equal
          value: true
          keep: false
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: vm-operator{{ if eq .Values.environment "client" }}-client{{ end }}
          jsonPath: $.spec.variables.dependency
          operator: Equal
          value: "True"
      selector:
        name: vm-operator
        priority: 30
        matchLabels:
          addons.in-cloud.io/values: "vm-operator"
          addons.in-cloud.io/addon: cilium
    - name: network-policies
      criteria:
        - source:
            apiVersion: v1
            kind: ConfigMap
            name: parameters{{ if eq .Values.environment "client" }}-client{{else}}-infra{{ end }}
            namespace: {{ .Values.companyPrefix }}-system
          jsonPath: $.data.environment
          operator: Equal
          value: "infra"
      selector:
        name: network-policies
        priority: 35
        matchLabels:
          addons.in-cloud.io/values: network-policies
          addons.in-cloud.io/addon: cilium
    - name: enforcement-always
      criteria:
        - source:
            apiVersion: v1
            kind: ConfigMap
            name: parameters{{ if eq .Values.environment "client" }}-client{{else}}-infra{{ end }}
            namespace: {{ .Values.companyPrefix }}-system
          jsonPath: $.data.environment
          operator: Equal
          value: "infra"
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: client-cp-control-plane
          jsonPath: $.status.deployed
          operator: Equal
          value: true
          keep: false
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: client-cp-control-plane
          jsonPath: $.status.phaseValuesSelector[?(@.name=='network-policies')]
          operator: Exists
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: cilium{{ if eq .Values.environment "client" }}-client{{ end }}
          jsonPath: $.status.phaseValuesSelector[?(@.name=='network-policies')]
          operator: Exists
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: cilium{{ if eq .Values.environment "client" }}-client{{ end }}
          jsonPath: $.spec.variables.dependency
          operator: Equal
          value: "True"
        - source:
            apiVersion: cilium.io/v2
            kind: CiliumNetworkPolicy
            name: allow-egress-argocd-repo-server-to-fqdns
            namespace: {{ .Values.companyPrefix }}-argocd
          jsonPath: $.status.conditions[?(@.type=='Valid' && @.status=='True')]
          operator: Exists
        - source:
            apiVersion: cilium.io/v2
            kind: CiliumNetworkPolicy
            name: allow-egress-argocd-application-controller-to-coredns-53
            namespace: {{ .Values.companyPrefix }}-coredns
          jsonPath: $.status.conditions[?(@.type=='Valid' && @.status=='True')]
          operator: Exists
        - source:
            apiVersion: cilium.io/v2
            kind: CiliumNetworkPolicy
            name: allow-ingress-kapi-and-rnode-to-addons-operator-9443
            namespace: {{ .Values.companyPrefix }}-addons-operator
          jsonPath: $.status.conditions[?(@.type=='Valid' && @.status=='True')]
          operator: Exists
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: extra-resources{{ if eq .Values.environment "client" }}-client{{ end }}
          jsonPath: $.status.phaseValuesSelector[?(@.name=='network-policies')]
          operator: Exists
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: client-cp-control-plane{{ if eq .Values.environment "client" }}-client{{ end }}
          jsonPath: $.status.phaseValuesSelector[?(@.name=='network-policies')]
          operator: Exists
      selector:
        name: enforcement-always
        priority: 40
        matchLabels:
          addons.in-cloud.io/values: enforcement-always
          addons.in-cloud.io/addon: cilium
{{- end }}
