{{- define "in-cloud-capi-template.files.kubectl.downloadScript.sh" }}
    LOG_TAG="kubectl-installer"
    TMP_DIR="$(mktemp -d)"

    logger -t "$LOG_TAG" "[INFO] Checking current kubectl version..."

    CURRENT_VERSION=$($INSTALL_PATH version -o json --client=true 2>/dev/null | jq -r '.clientVersion.gitVersion' | sed 's/^v//') || CURRENT_VERSION="none"
    COMPONENT_VERSION_CLEAN=$(echo "$COMPONENT_VERSION" | sed 's/^v//')

    logger -t "$LOG_TAG" "[INFO] Current: $CURRENT_VERSION, Target: $COMPONENT_VERSION_CLEAN"

    if [[ "$CURRENT_VERSION" != "$COMPONENT_VERSION_CLEAN" ]]; then
      logger -t "$LOG_TAG" "[INFO] Download URL: $PATH_BIN"
      logger -t "$LOG_TAG" "[INFO] Updating kubectl to version $COMPONENT_VERSION_CLEAN..."

      cd "$TMP_DIR"
      logger -t "$LOG_TAG" "[INFO] Working directory: $PWD"

      logger -t "$LOG_TAG" "[INFO] Downloading kubectl..."
      curl -fsSL -o kubectl "$PATH_BIN" || { logger -t "$LOG_TAG" "[ERROR] Failed to download kubectl"; exit 1; }

      logger -t "$LOG_TAG" "[INFO] Downloading checksum file..."
      curl -fsSL -o kubectl.sha256sum "$PATH_SHA256" || { logger -t "$LOG_TAG" "[ERROR] Failed to download checksum file"; exit 1; }

      logger -t "$LOG_TAG" "[INFO] Verifying checksum..."
      awk '{print $1"  kubectl"}' kubectl.sha256sum | sha256sum -c - || { logger -t "$LOG_TAG" "[ERROR] Checksum verification failed!"; exit 1; }

      logger -t "$LOG_TAG" "[INFO] Installing kubectl..."
      install -m 755 kubectl "$INSTALL_PATH"

      logger -t "$LOG_TAG" "[INFO] kubectl successfully updated to $COMPONENT_VERSION_CLEAN."
      rm -rf "$TMP_DIR"

    else
      logger -t "$LOG_TAG" "[INFO] kubectl is already up to date. Skipping installation."
    fi
{{- end }}
