{{- define "addons-operator.phase" }}
---
apiVersion: addons.in-cloud.io/v1alpha1
kind: AddonPhase
metadata:
  name: addons-operator{{ if eq .Values.environment "client" }}-client{{ end }}
spec:
  rules:
    - name: cert-manager
      criteria:
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: cert-manager{{ if eq .Values.environment "client" }}-client{{ end }}
          jsonPath: $.status.phaseValuesSelector[?(@.name=='initialized-2')].deployed
          operator: Equal
          value: true
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: cert-manager{{ if eq .Values.environment "client" }}-client{{ end }}
          jsonPath: $.spec.variables.dependency
          operator: Equal
          value: "True"
      selector:
        name: cert-manager
        priority: 20
        matchLabels:
          addons.in-cloud.io/values: cert-manager
          addons.in-cloud.io/addon: addons-operator
    # - name: infra
    #   criteria:
    #     - source:
    #         apiVersion: v1
    #         kind: ConfigMap
    #         name: parameters{{ if eq .Values.environment "client" }}-client{{else}}-infra{{ end }}
    #         namespace: {{ .Values.companyPrefix }}-system
    #       jsonPath: $.data.environment
    #       operator: Equal
    #       value: "infra"
    #   selector:
    #     name: infra
    #     priority: 23
    #     matchLabels:
    #       addons.in-cloud.io/values: infra
    #       addons.in-cloud.io/addon: addons-operator
    - name: system
      criteria:
        - source:
            apiVersion: v1
            kind: ConfigMap
            name: parameters{{ if eq .Values.environment "client" }}-client{{else}}-infra{{ end }}
            namespace: {{ .Values.companyPrefix }}-system
          jsonPath: $.data.systemEnabled
          operator: Equal
          value: "true"
      selector:
        name: system
        priority: 25
        matchLabels:
          addons.in-cloud.io/values: system
          addons.in-cloud.io/addon: addons-operator
    {{- if eq .Values.environment "infra" }}
    - name: network-policies
      criteria:
        - source:
            apiVersion: v1
            kind: ConfigMap
            name: parameters-infra
            namespace: {{ .Values.companyPrefix }}-system
          jsonPath: $.data.environment
          operator: Equal
          value: "infra"
        - source:
            apiVersion: addons.in-cloud.io/v1alpha1
            kind: Addon
            name: cilium
          jsonPath: $.status.deployed
          operator: Equal
          value: true
          keep: false
      selector:
        name: network-policies
        priority: 30
        matchLabels:
          addons.in-cloud.io/values: network-policies
          addons.in-cloud.io/addon: addons-operator
    {{- end }}
    - name: disable-webhook
      criteria:
        - source:
            apiVersion: argoproj.io/v1alpha1
            kind: Application
            name: addonset
            namespace: {{ .Values.companyPrefix }}-argocd
          jsonPath: $.status.sync.status
          operator: NotEqual
          value: Synced
          keep: false
        - source:
            apiVersion: argoproj.io/v1alpha1
            kind: Application
            name: addonset
            namespace: {{ .Values.companyPrefix }}-argocd
          jsonPath: $.spec.syncPolicy.automated
          operator: Exists
          keep: false
      selector:
        name: disable-webhook
        priority: 85
        matchLabels:
          addons.in-cloud.io/values: disable-webhook
          addons.in-cloud.io/addon: addons-operator
{{- end }}
