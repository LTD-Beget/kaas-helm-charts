{{- define "etcd-backup-snapshot.addon" }}
---
apiVersion: addons.in-cloud.io/v1alpha1
kind: Addon
metadata:
  name: etcd-backup-snapshot
spec:
  chart: "etcd-backup-snapshot"
  pluginName: helm-with-values
  repoURL: "{{ .Values.companyExternalChartRegistry }}"
  version: "0.1.0"
  targetCluster: in-cluster
  targetNamespace: "{{ .Values.companyPrefix }}-etcd-backup-snapshot"
  variables:
    cluster_name: in-cluster
    dependency: "True"
  valuesSources:
    - name: parameters-infra
      sourceRef:
        apiVersion: v1
        kind: ConfigMap
        name: parameters-infra
        namespace: {{ .Values.companyPrefix }}-system
      extract:
        - as: cluster.name
          jsonPath: .data.clusterName
        - as: etcdbackupAppArgsStorecontainer
          jsonPath: .data.etcdbackupAppArgsStorecontainer
        - as: etcdbackupS3AccessKey
          jsonPath: .data.etcdbackupS3AccessKey
        - as: etcdbackupS3SecretAccessKey
          jsonPath: .data.etcdbackupS3SecretAccessKey
        - as: etcdbackupS3SecretEndpoint
          jsonPath: .data.etcdbackupS3SecretEndpoint
        - as: companyPrefix
          jsonPath: .data.companyPrefix
        - as: companyDomain
          jsonPath: .data.companyDomain
{{- if .Values.clientClusterEnabled }}
  initDependencies:
    - name: client-cp-control-plane
      criteria:
        - jsonPath: $.status.deployed
          operator: Equal
          value: true
{{- end }}
  backend:
    finalizer: true
    type: "argocd"
    namespace: "{{ .Values.companyPrefix }}-argocd"
    project: "default"
    syncPolicy:
      automated:
        prune: true
      managedNamespaceMetadata:
        labels:
          in-cloud.io/caBundle: approved
          in-cloud.io/clusterName: infra
      syncOptions:
        - ApplyOutOfSyncOnly=true
        - CreateNamespace=true
  valuesSelectors:
    - name: default
      priority: 0
      matchLabels:
        addons.in-cloud.io/values: default
        addons.in-cloud.io/addon: etcd-backup-snapshot
    - name: immutable
      priority: 99
      matchLabels:
        addons.in-cloud.io/values: immutable
        addons.in-cloud.io/addon: etcd-backup-snapshot
{{- end }}
